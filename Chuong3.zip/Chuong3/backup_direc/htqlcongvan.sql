

--
-- Cơ sở dữ liệu: `htqlcongvan`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblfiledinhkem`
--

CREATE TABLE `tblfiledinhkem` (
  `FileID` int(11) NOT NULL,
  `Url` varchar(255) DEFAULT NULL,
  `Size` int(11) DEFAULT NULL,
  `DateUpload` date DEFAULT NULL,
  `MaCV` int(11) DEFAULT NULL,
  `TenFile` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblloaicv`
--

CREATE TABLE `tblloaicv` (
  `MaLoaiCV` int(11) NOT NULL,
  `TenLoaiCV` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblnguoidung`
--

CREATE TABLE `tblnguoidung` (
  `MaNguoiDung` int(11) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `TenDN` varchar(255) DEFAULT NULL,
  `MatKhau` varchar(255) DEFAULT NULL,
  `QuyenHan` varchar(255) DEFAULT NULL,
  `HoTen` varchar(255) DEFAULT NULL,
  `MaNhom` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblnhan`
--

CREATE TABLE `tblnhan` (
  `MaCV` int(11) NOT NULL,
  `MaNguoiDung` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblnhom`
--

CREATE TABLE `tblnhom` (
  `MaNhom` int(11) NOT NULL,
  `TenNhom` varchar(255) DEFAULT NULL,
  `MoTa` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tblnoidungcv`
--

CREATE TABLE `tblnoidungcv` (
  `MaCV` int(11) NOT NULL,
  `MaLoaiCV` int(11) DEFAULT NULL,
  `TieuDeCV` varchar(255) DEFAULT NULL,
  `NgayGui` date DEFAULT NULL,
  `SoCV` varchar(50) DEFAULT NULL,
  `CoQuanBanHanh` varchar(255) DEFAULT NULL,
  `NgayBanHanh` date DEFAULT NULL,
  `TrichYeuND` text DEFAULT NULL,
  `NguoiKy` varchar(255) DEFAULT NULL,
  `NoiNhan` varchar(255) DEFAULT NULL,
  `TuKhoa` varchar(255) DEFAULT NULL,
  `TrangThai` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `tblfiledinhkem`
--
ALTER TABLE `tblfiledinhkem`
  ADD PRIMARY KEY (`FileID`),
  ADD KEY `MaCV` (`MaCV`);

--
-- Chỉ mục cho bảng `tblloaicv`
--
ALTER TABLE `tblloaicv`
  ADD PRIMARY KEY (`MaLoaiCV`);

--
-- Chỉ mục cho bảng `tblnguoidung`
--
ALTER TABLE `tblnguoidung`
  ADD PRIMARY KEY (`MaNguoiDung`),
  ADD KEY `MaNhom` (`MaNhom`);

--
-- Chỉ mục cho bảng `tblnhan`
--
ALTER TABLE `tblnhan`
  ADD PRIMARY KEY (`MaCV`,`MaNguoiDung`),
  ADD KEY `MaNguoiDung` (`MaNguoiDung`);

--
-- Chỉ mục cho bảng `tblnhom`
--
ALTER TABLE `tblnhom`
  ADD PRIMARY KEY (`MaNhom`);

--
-- Chỉ mục cho bảng `tblnoidungcv`
--
ALTER TABLE `tblnoidungcv`
  ADD PRIMARY KEY (`MaCV`),
  ADD KEY `MaLoaiCV` (`MaLoaiCV`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `tblfiledinhkem`
--
ALTER TABLE `tblfiledinhkem`
  MODIFY `FileID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tblloaicv`
--
ALTER TABLE `tblloaicv`
  MODIFY `MaLoaiCV` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tblnguoidung`
--
ALTER TABLE `tblnguoidung`
  MODIFY `MaNguoiDung` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tblnhom`
--
ALTER TABLE `tblnhom`
  MODIFY `MaNhom` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `tblnoidungcv`
--
ALTER TABLE `tblnoidungcv`
  MODIFY `MaCV` int(11) NOT NULL AUTO_INCREMENT;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `tblfiledinhkem`
--
ALTER TABLE `tblfiledinhkem`
  ADD CONSTRAINT `tblfiledinhkem_ibfk_1` FOREIGN KEY (`MaCV`) REFERENCES `tblnoidungcv` (`MaCV`);

--
-- Các ràng buộc cho bảng `tblnguoidung`
--
ALTER TABLE `tblnguoidung`
  ADD CONSTRAINT `tblnguoidung_ibfk_1` FOREIGN KEY (`MaNhom`) REFERENCES `tblnhom` (`MaNhom`);

--
-- Các ràng buộc cho bảng `tblnhan`
--
ALTER TABLE `tblnhan`
  ADD CONSTRAINT `tblnhan_ibfk_1` FOREIGN KEY (`MaCV`) REFERENCES `tblnoidungcv` (`MaCV`),
  ADD CONSTRAINT `tblnhan_ibfk_2` FOREIGN KEY (`MaNguoiDung`) REFERENCES `tblnguoidung` (`MaNguoiDung`);

--
-- Các ràng buộc cho bảng `tblnoidungcv`
--
ALTER TABLE `tblnoidungcv`
  ADD CONSTRAINT `tblnoidungcv_ibfk_1` FOREIGN KEY (`MaLoaiCV`) REFERENCES `tblloaicv` (`MaLoaiCV`);
COMMIT;


